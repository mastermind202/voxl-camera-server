/*
00002  * Copyright (c) 2007 The Khronos Group Inc. 
00003  * 
00004  * Permission is hereby granted, free of charge, to any person obtaining
00005  * a copy of this software and associated documentation files (the
00006  * "Software"), to deal in the Software without restriction, including
00007  * without limitation the rights to use, copy, modify, merge, publish,
00008  * distribute, sublicense, and/or sell copies of the Software, and to
00009  * permit persons to whom the Software is furnished to do so, subject
00010  * to the following conditions: 
00011  * The above copyright notice and this permission notice shall be included
00012  * in all copies or substantial portions of the Software. 
00013  * 
00014  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
00015  * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
00016  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
00017  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
00018  * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
00019  * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
00020  * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
00021  *
00022  */
00023 
00030 #ifndef OMX_Component_h
00031 #define OMX_Component_h
00032 
00033 #ifdef __cplusplus
00034 extern "C" {
00035 #endif /* __cplusplus */
00036 
00037 
00038 
00039 /* Each OMX header must include all required header files to allow the
00040  *  header to compile without errors.  The includes below are required
00041  *  for this header file to compile successfully 
00042  */
00043 
00044 #include <OMX_Audio.h>
00045 #include <OMX_Video.h>
00046 #include <OMX_Image.h>
00047 #include <OMX_Other.h>
00048 
00050 typedef enum OMX_PORTDOMAINTYPE { 
00051     OMX_PortDomainAudio, 
00052     OMX_PortDomainVideo, 
00053     OMX_PortDomainImage, 
00054     OMX_PortDomainOther,
00055     OMX_PortDomainMax = 0x7ffffff
00056 } OMX_PORTDOMAINTYPE;
00057 
00059 typedef struct OMX_PARAM_PORTDEFINITIONTYPE {
00060     OMX_U32 nSize;                 
00061     OMX_VERSIONTYPE nVersion;      
00062     OMX_U32 nPortIndex;            
00063     OMX_DIRTYPE eDir;              
00064     OMX_U32 nBufferCountActual;    
00065     OMX_U32 nBufferCountMin;       
00066     OMX_U32 nBufferSize;           
00067     OMX_BOOL bEnabled;             
00071     OMX_BOOL bPopulated;           
00075     OMX_PORTDOMAINTYPE eDomain;    
00076     union {
00077         OMX_AUDIO_PORTDEFINITIONTYPE audio;
00078         OMX_VIDEO_PORTDEFINITIONTYPE video;
00079         OMX_IMAGE_PORTDEFINITIONTYPE image;
00080         OMX_OTHER_PORTDEFINITIONTYPE other;
00081     } format;
00082     OMX_BOOL bBuffersContiguous;
00083     OMX_U32 nBufferAlignment;
00084 } OMX_PARAM_PORTDEFINITIONTYPE;
00085 
00087 typedef struct OMX_PARAM_U32TYPE { 
00088     OMX_U32 nSize;                    
00089     OMX_VERSIONTYPE nVersion;         
00090     OMX_U32 nPortIndex;               
00091     OMX_U32 nU32;                     
00092 } OMX_PARAM_U32TYPE;
00093 
00095 typedef enum OMX_SUSPENSIONPOLICYTYPE {
00096     OMX_SuspensionDisabled, 
00097     OMX_SuspensionEnabled,  
00098     OMX_SuspensionPolicyMax = 0x7fffffff
00099 } OMX_SUSPENSIONPOLICYTYPE;
00100 
00102 typedef struct OMX_PARAM_SUSPENSIONPOLICYTYPE {
00103     OMX_U32 nSize;                  
00104     OMX_VERSIONTYPE nVersion;        
00105     OMX_SUSPENSIONPOLICYTYPE ePolicy;
00106 } OMX_PARAM_SUSPENSIONPOLICYTYPE;
00107 
00109 typedef enum OMX_SUSPENSIONTYPE {
00110     OMX_NotSuspended, 
00111     OMX_Suspended,    
00112     OMX_SuspendMax = 0x7FFFFFFF
00113 } OMX_SUSPENSIONTYPE;
00114 
00116 typedef struct OMX_PARAM_SUSPENSIONTYPE {
00117     OMX_U32 nSize;                  
00118     OMX_VERSIONTYPE nVersion;       
00119     OMX_SUSPENSIONTYPE eType;             
00120 } OMX_PARAM_SUSPENSIONTYPE ;
00121 
00122 typedef struct OMX_CONFIG_BOOLEANTYPE {
00123     OMX_U32 nSize;
00124     OMX_VERSIONTYPE nVersion;
00125     OMX_BOOL bEnabled;    
00126 } OMX_CONFIG_BOOLEANTYPE;
00127 
00128 /* Parameter specifying the content uri to use. */
00130 typedef struct OMX_PARAM_CONTENTURITYPE
00131 {
00132     OMX_U32 nSize;                      
00134     OMX_VERSIONTYPE nVersion;           
00135     OMX_U8 contentURI[1];               
00136 } OMX_PARAM_CONTENTURITYPE;
00137 
00138 /* Parameter specifying the pipe to use. */
00140 typedef struct OMX_PARAM_CONTENTPIPETYPE
00141 {
00142     OMX_U32 nSize;              
00143     OMX_VERSIONTYPE nVersion;   
00144     OMX_HANDLETYPE hPipe;       
00145 } OMX_PARAM_CONTENTPIPETYPE;
00146 
00148 typedef struct OMX_RESOURCECONCEALMENTTYPE {
00149     OMX_U32 nSize;             
00150     OMX_VERSIONTYPE nVersion;  
00151     OMX_BOOL bResourceConcealmentForbidden; 
00155 } OMX_RESOURCECONCEALMENTTYPE;
00156 
00157 
00159 typedef enum OMX_METADATACHARSETTYPE {
00160     OMX_MetadataCharsetUnknown = 0,
00161     OMX_MetadataCharsetASCII,
00162     OMX_MetadataCharsetBinary,
00163     OMX_MetadataCharsetCodePage1252,
00164     OMX_MetadataCharsetUTF8,
00165     OMX_MetadataCharsetJavaConformantUTF8,
00166     OMX_MetadataCharsetUTF7,
00167     OMX_MetadataCharsetImapUTF7,
00168     OMX_MetadataCharsetUTF16LE, 
00169     OMX_MetadataCharsetUTF16BE,
00170     OMX_MetadataCharsetGB12345,
00171     OMX_MetadataCharsetHZGB2312,
00172     OMX_MetadataCharsetGB2312,
00173     OMX_MetadataCharsetGB18030,
00174     OMX_MetadataCharsetGBK,
00175     OMX_MetadataCharsetBig5,
00176     OMX_MetadataCharsetISO88591,
00177     OMX_MetadataCharsetISO88592,
00178     OMX_MetadataCharsetISO88593,
00179     OMX_MetadataCharsetISO88594,
00180     OMX_MetadataCharsetISO88595,
00181     OMX_MetadataCharsetISO88596,
00182     OMX_MetadataCharsetISO88597,
00183     OMX_MetadataCharsetISO88598,
00184     OMX_MetadataCharsetISO88599,
00185     OMX_MetadataCharsetISO885910,
00186     OMX_MetadataCharsetISO885913,
00187     OMX_MetadataCharsetISO885914,
00188     OMX_MetadataCharsetISO885915,
00189     OMX_MetadataCharsetShiftJIS,
00190     OMX_MetadataCharsetISO2022JP,
00191     OMX_MetadataCharsetISO2022JP1,
00192     OMX_MetadataCharsetISOEUCJP,
00193     OMX_MetadataCharsetSMS7Bit,
00194     OMX_MetadataCharsetTypeMax= 0x7FFFFFFF
00195 } OMX_METADATACHARSETTYPE;
00196 
00198 typedef enum OMX_METADATASCOPETYPE
00199 {
00200     OMX_MetadataScopeAllLevels,
00201     OMX_MetadataScopeTopLevel,
00202     OMX_MetadataScopePortLevel,
00203     OMX_MetadataScopeNodeLevel,
00204     OMX_MetadataScopeTypeMax = 0x7fffffff
00205 } OMX_METADATASCOPETYPE;
00206 
00208 typedef enum OMX_METADATASEARCHMODETYPE
00209 {
00210     OMX_MetadataSearchValueSizeByIndex,
00211     OMX_MetadataSearchItemByIndex,
00212     OMX_MetadataSearchNextItemByKey,
00213     OMX_MetadataSearchTypeMax = 0x7fffffff
00214 } OMX_METADATASEARCHMODETYPE;
00216 typedef struct OMX_CONFIG_METADATAITEMCOUNTTYPE
00217 {
00218     OMX_U32 nSize;
00219     OMX_VERSIONTYPE nVersion;
00220     OMX_METADATASCOPETYPE eScopeMode;
00221     OMX_U32 nScopeSpecifier;
00222     OMX_U32 nMetadataItemCount;
00223 } OMX_CONFIG_METADATAITEMCOUNTTYPE;
00224 
00226 typedef struct OMX_CONFIG_METADATAITEMTYPE
00227 {
00228     OMX_U32 nSize;
00229     OMX_VERSIONTYPE nVersion;
00230     OMX_METADATASCOPETYPE eScopeMode;
00231     OMX_U32 nScopeSpecifier;
00232     OMX_U32 nMetadataItemIndex;  
00233     OMX_METADATASEARCHMODETYPE eSearchMode;
00234     OMX_METADATACHARSETTYPE eKeyCharset;
00235     OMX_U8 nKeySizeUsed;
00236     OMX_U8 nKey[128];
00237     OMX_METADATACHARSETTYPE eValueCharset;
00238     OMX_STRING sLanguageCountry;
00239     OMX_U32 nValueMaxSize;
00240     OMX_U32 nValueSizeUsed;
00241     OMX_U8 nValue[1];
00242 } OMX_CONFIG_METADATAITEMTYPE;
00243 
00244 /* @ingroup metadata */
00245 typedef struct OMX_CONFIG_CONTAINERNODECOUNTTYPE
00246 {
00247     OMX_U32 nSize;
00248     OMX_VERSIONTYPE nVersion;
00249     OMX_BOOL bAllKeys;
00250     OMX_U32 nParentNodeID;
00251     OMX_U32 nNumNodes;
00252 } OMX_CONFIG_CONTAINERNODECOUNTTYPE;
00253 
00255 typedef struct OMX_CONFIG_CONTAINERNODEIDTYPE
00256 {
00257     OMX_U32 nSize;
00258     OMX_VERSIONTYPE nVersion;
00259     OMX_BOOL bAllKeys;
00260     OMX_U32 nParentNodeID;
00261     OMX_U32 nNodeIndex; 
00262     OMX_U32 nNodeID; 
00263     OMX_STRING cNodeName;
00264     OMX_BOOL bIsLeafType;
00265 } OMX_CONFIG_CONTAINERNODEIDTYPE;
00266 
00268 typedef struct OMX_PARAM_METADATAFILTERTYPE 
00269 { 
00270     OMX_U32 nSize; 
00271     OMX_VERSIONTYPE nVersion; 
00272     OMX_BOOL bAllKeys;  /* if true then this structure refers to all keys and 
00273                          * the three key fields below are ignored */
00274     OMX_METADATACHARSETTYPE eKeyCharset;
00275     OMX_U32 nKeySizeUsed; 
00276     OMX_U8   nKey [128]; 
00277     OMX_U32 nLanguageCountrySizeUsed;
00278     OMX_U8 nLanguageCountry[128];
00279     OMX_BOOL bEnabled;  /* if true then key is part of filter (e.g. 
00280                          * retained for query later). If false then
00281                          * key is not part of filter */
00282 } OMX_PARAM_METADATAFILTERTYPE; 
00283 
00295 typedef struct OMX_COMPONENTTYPE
00296 {
00301     OMX_U32 nSize;
00302 
00308     OMX_VERSIONTYPE nVersion;
00309 
00314     OMX_PTR pComponentPrivate;
00315 
00320     OMX_PTR pApplicationPrivate;
00321 
00325     OMX_ERRORTYPE (*GetComponentVersion)(
00326             OMX_IN  OMX_HANDLETYPE hComponent,
00327             OMX_OUT OMX_STRING pComponentName,
00328             OMX_OUT OMX_VERSIONTYPE* pComponentVersion,
00329             OMX_OUT OMX_VERSIONTYPE* pSpecVersion,
00330             OMX_OUT OMX_UUIDTYPE* pComponentUUID);
00331 
00335     OMX_ERRORTYPE (*SendCommand)(
00336             OMX_IN  OMX_HANDLETYPE hComponent,
00337             OMX_IN  OMX_COMMANDTYPE Cmd,
00338             OMX_IN  OMX_U32 nParam1,
00339             OMX_IN  OMX_PTR pCmdData);
00340 
00344     OMX_ERRORTYPE (*GetParameter)(
00345             OMX_IN  OMX_HANDLETYPE hComponent, 
00346             OMX_IN  OMX_INDEXTYPE nParamIndex,  
00347             OMX_INOUT OMX_PTR pComponentParameterStructure);
00348 
00349 
00353     OMX_ERRORTYPE (*SetParameter)(
00354             OMX_IN  OMX_HANDLETYPE hComponent, 
00355             OMX_IN  OMX_INDEXTYPE nIndex,
00356             OMX_IN  OMX_PTR pComponentParameterStructure);
00357 
00358 
00362     OMX_ERRORTYPE (*GetConfig)(
00363             OMX_IN  OMX_HANDLETYPE hComponent,
00364             OMX_IN  OMX_INDEXTYPE nIndex, 
00365             OMX_INOUT OMX_PTR pComponentConfigStructure);
00366 
00367 
00371     OMX_ERRORTYPE (*SetConfig)(
00372             OMX_IN  OMX_HANDLETYPE hComponent,
00373             OMX_IN  OMX_INDEXTYPE nIndex, 
00374             OMX_IN  OMX_PTR pComponentConfigStructure);
00375 
00376 
00380     OMX_ERRORTYPE (*GetExtensionIndex)(
00381             OMX_IN  OMX_HANDLETYPE hComponent,
00382             OMX_IN  OMX_STRING cParameterName,
00383             OMX_OUT OMX_INDEXTYPE* pIndexType);
00384 
00385 
00389     OMX_ERRORTYPE (*GetState)(
00390             OMX_IN  OMX_HANDLETYPE hComponent,
00391             OMX_OUT OMX_STATETYPE* pState);
00392 
00393     
00455     OMX_ERRORTYPE (*ComponentTunnelRequest)(
00456         OMX_IN  OMX_HANDLETYPE hComp,
00457         OMX_IN  OMX_U32 nPort,
00458         OMX_IN  OMX_HANDLETYPE hTunneledComp,
00459         OMX_IN  OMX_U32 nTunneledPort,
00460         OMX_INOUT  OMX_TUNNELSETUPTYPE* pTunnelSetup); 
00461 
00466     OMX_ERRORTYPE (*UseBuffer)(
00467             OMX_IN OMX_HANDLETYPE hComponent,
00468             OMX_INOUT OMX_BUFFERHEADERTYPE** ppBufferHdr,
00469             OMX_IN OMX_U32 nPortIndex,
00470             OMX_IN OMX_PTR pAppPrivate,
00471             OMX_IN OMX_U32 nSizeBytes,
00472             OMX_IN OMX_U8* pBuffer);
00473 
00478     OMX_ERRORTYPE (*AllocateBuffer)(
00479             OMX_IN OMX_HANDLETYPE hComponent,
00480             OMX_INOUT OMX_BUFFERHEADERTYPE** ppBuffer,
00481             OMX_IN OMX_U32 nPortIndex,
00482             OMX_IN OMX_PTR pAppPrivate,
00483             OMX_IN OMX_U32 nSizeBytes);
00484 
00489     OMX_ERRORTYPE (*FreeBuffer)(
00490             OMX_IN  OMX_HANDLETYPE hComponent,
00491             OMX_IN  OMX_U32 nPortIndex,
00492             OMX_IN  OMX_BUFFERHEADERTYPE* pBuffer);
00493 
00498     OMX_ERRORTYPE (*EmptyThisBuffer)(
00499             OMX_IN  OMX_HANDLETYPE hComponent,
00500             OMX_IN  OMX_BUFFERHEADERTYPE* pBuffer);
00501 
00506     OMX_ERRORTYPE (*FillThisBuffer)(
00507             OMX_IN  OMX_HANDLETYPE hComponent,
00508             OMX_IN  OMX_BUFFERHEADERTYPE* pBuffer);
00509 
00528     OMX_ERRORTYPE (*SetCallbacks)(
00529             OMX_IN  OMX_HANDLETYPE hComponent,
00530             OMX_IN  OMX_CALLBACKTYPE* pCallbacks, 
00531             OMX_IN  OMX_PTR pAppData);
00532 
00544     OMX_ERRORTYPE (*ComponentDeInit)(
00545             OMX_IN  OMX_HANDLETYPE hComponent);
00546 
00548     OMX_ERRORTYPE (*UseEGLImage)(
00549             OMX_IN OMX_HANDLETYPE hComponent,
00550             OMX_INOUT OMX_BUFFERHEADERTYPE** ppBufferHdr,
00551             OMX_IN OMX_U32 nPortIndex,
00552             OMX_IN OMX_PTR pAppPrivate,
00553             OMX_IN void* eglImage);
00554 
00555     OMX_ERRORTYPE (*ComponentRoleEnum)(
00556         OMX_IN OMX_HANDLETYPE hComponent,
00557         OMX_OUT OMX_U8 *cRole,
00558         OMX_IN OMX_U32 nIndex);
00559 
00560 } OMX_COMPONENTTYPE;
00561 
00562 #ifdef __cplusplus
00563 }
00564 #endif /* __cplusplus */
00565 
00566 #endif
00567 /* File EOF */
